# Lab 2, demand paging
This lab simulates a pager and accounts for machine size, page size, and process size.
Outputs number of faults for each process and average residency, as well as total number of faults and overall average residency.